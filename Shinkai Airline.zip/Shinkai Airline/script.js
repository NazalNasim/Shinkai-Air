// script.js

function goToMenu() {
  window.location.href = "menu.html";
}

// Swipe for mobile
let startX = 0;
document.addEventListener('touchstart', (e) => {
  startX = e.touches[0].clientX;
});

document.addEventListener('touchend', (e) => {
  const endX = e.changedTouches[0].clientX;
  if (startX - endX > 50) {
    // Swipe left → menu
    goToMenu();
  }
});
